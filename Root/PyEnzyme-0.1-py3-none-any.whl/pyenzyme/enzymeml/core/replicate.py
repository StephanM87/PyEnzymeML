'''
Created on 10.06.2020

@author: JR
'''

from pyenzyme.enzymeml.core.functionalities import TypeChecker
from pandas.core.series import Series


class Replicate(object):
    
    '''
    TimeSeries data = new TimeSeries();
    
    public String replica;
    String species;
    String type;
    String unit;
    '''

    def __init__(self, replica, reactant, type_, data_unit, time_unit):
        '''
        Args:
            replica: Replicate internal identifier
            species: Species internal identifier
            type: Type of time series data
            data_unit: Unit definition for data 
            time_unit: Unit definition for time
        '''
        
        self.setReplica(replica)
        self.setReactant(reactant)
        self.setType(type_)
        self.setDataUnit(data_unit)
        self.setTimeUnit(time_unit)
        
    def getReplica(self):
        return self.__replica


    def getReactant(self):
        return self.__species


    def getType(self):
        return self.__type


    def getDataUnit(self):
        return self.__data_unit


    def getTimeUnit(self):
        return self.__time_unit


    def getData(self):
        return self.__data


    def setReplica(self, replica_id):
        self.__replica = TypeChecker(replica_id, str)


    def setReactant(self, reactant_id):
        self.__species = TypeChecker(reactant_id, str)


    def setType(self, type_):
        self.__type = TypeChecker(type_, str)


    def setDataUnit(self, unit_id):
        self.__data_unit = TypeChecker(unit_id, str)


    def setTimeUnit(self, unit_id):
        self.__time_unit = TypeChecker(unit_id, str)


    def setData(self, data):
        self.__data = TypeChecker(data, Series)


    def delReplica(self):
        del self.__replica


    def delReactant(self):
        del self.__species


    def delType(self):
        del self.__type


    def delDataUnit(self):
        del self.__data_unit


    def delTimeUnit(self):
        del self.__time_unit


    def delData(self):
        del self.__data

    _replica = property(getReplica, setReplica, delReplica, "_replica's docstring")
    _type = property(getType, setType, delType, "_type's docstring")
    _data_unit = property(getDataUnit, setDataUnit, delDataUnit, "_data_unit's docstring")
    _time_unit = property(getTimeUnit, setTimeUnit, delTimeUnit, "_time_unit's docstring")
    _data = property(getData, setData, delData, "_data's docstring")
    _reactant = property(None, None, None, "_reactant's docstring")
        
        
        
        
        
        

        
        
        