'''
Created on 09.06.2020

@author: JR
'''

## TODO - AddXXX Functions

from pyenzyme.enzymeml.core.functionalities import TypeChecker
from pyenzyme.enzymeml.core import Creator
from pyenzyme.enzymeml.core.vessel import Vessel


class EnzymeMLDocument(object):

    def __init__(self, name, level, version):
        '''
        Super class of an enzymeml document, holding all relevant information
        
        Args:
            name: Document name
            level: SBML Level
            version: SBML Version
        '''
        
        self.setName(name)
        self.setLevel(level)
        self.setVersion(version)
        
        self.setProteinDict(dict())
        self.setReactantDict(dict())
        self.setReactionDict(dict())
        self.setUnitDict(dict())

    def get_created(self):
        return self.__created


    def get_modified(self):
        return self.__modified


    def set_created(self, date):
        self.__created = TypeChecker(date, str)


    def set_modified(self, date):
        self.__modified = TypeChecker(date, str)


    def del_created(self):
        del self.__created


    def del_modified(self):
        del self.__modified


    def get_creator(self):
        return self.__creator


    def set_creator(self, creators):
        
        if type(creators) == list:
            self.__creator = [ TypeChecker(creator, Creator) for creator in creators ]
        else:
            self.__creator = [TypeChecker(creators, Creator)]


    def del_creator(self):
        del self.__creator


    def getVessel(self):
        return self.__vessel


    def setVessel(self, vessel):
        self.__vessel = TypeChecker(vessel, Vessel)


    def delVessel(self):
        del self.__vessel


    def getName(self):
        return self.__name


    def getLevel(self):
        return self.__level


    def getVersion(self):
        return self.__version


    def getProteinDict(self):
        return self.__ProteinDict


    def getReactantDict(self):
        return self.__ReactantDict


    def getReactionDict(self):
        return self.__ReactionDict


    def getUnitDict(self):
        return self.__UnitDict


    def setName(self, value):
        self.__name = value


    def setLevel(self, level):
        
        if 1 <= TypeChecker(level, int) <= 3:
            self.__level = level
        else:
            raise IndexError("Level out of bounds. SBML level is defined from 1 to 3.")


    def setVersion(self, version):
        self.__version = TypeChecker(version, int)


    def setProteinDict(self, proteinDict):
        self.__ProteinDict = TypeChecker(proteinDict, dict)


    def setReactantDict(self, reactantDict):
        self.__ReactantDict = TypeChecker(reactantDict, dict)


    def setReactionDict(self, reactionDict):
        self.__ReactionDict = TypeChecker(reactionDict, dict)


    def setUnitDict(self, unitDict):
        self.__UnitDict = TypeChecker(unitDict, dict)


    def delName(self):
        del self.__name


    def delLevel(self):
        del self.__level


    def delVersion(self):
        del self.__version


    def delProteinDict(self):
        del self.__ProteinDict


    def delReactantDict(self):
        del self.__ReactantDict


    def delReactionDict(self):
        del self.__ReactionDict


    def delUnitDict(self):
        del self.__UnitDict

    _name = property(getName, setName, delName, "_name's docstring")
    _level = property(getLevel, setLevel, delLevel, "_level's docstring")
    _version = property(getVersion, setVersion, delVersion, "_version's docstring")
    _ProteinDict = property(getProteinDict, setProteinDict, delProteinDict, "_ProteinDict's docstring")
    _ReactantDict = property(getReactantDict, setReactantDict, delReactantDict, "_ReactantDict's docstring")
    _ReactionDict = property(getReactionDict, setReactionDict, delReactionDict, "_ReactionDict's docstring")
    _UnitDict = property(getUnitDict, setUnitDict, delUnitDict, "_UnitDict's docstring")
    _vessel = property(getVessel, setVessel, delVessel, "_vessel's docstring")
    _creator = property(get_creator, set_creator, del_creator, "_creator's docstring")
    _created = property(get_created, set_created, del_created, "_created's docstring")
    _modified = property(get_modified, set_modified, del_modified, "_modified's docstring")
        
        