'''
Created on 10.06.2020

@author: JR
'''

from pyenzyme.enzymeml.core import Protein, Reactant, Replicate, UnitDef, Vessel, EnzymeMLDocument, EnzymeReaction, Creator
from libsbml import SBMLReader
import xml.etree.ElementTree as ET
import pandas as pd
from pyenzyme.enzymeml.models.kineticmodel import KineticModel
from libcombine import CombineArchive
from _io import StringIO


class EnzymeMLReader(object):

    def readFromFile(self, path, omex=False):
        
        self.omex = omex
        self.__path = path
        
        if self.omex:
            self.archive = CombineArchive()
            self.archive.initializeFromArchive(self.__path)
        
            sbmlfile = self.archive.getEntry(0)
            content = self.archive.extractEntryToString(sbmlfile.getLocation())

        
        reader = SBMLReader()
        
        if self.omex:
            document = reader.readSBMLFromString(content)

        else:
            document = reader.readSBMLFromFile(self.__path + '/experiment.xml')
        
        model = document.getModel()
        
        enzmldoc = EnzymeMLDocument(model.getName(), model.getLevel(), model.getVersion())
        
        # Fetch meta data
        try:
            creators = self.__getCreators(model)
            enzmldoc.set_creator(creators)
        except AttributeError:
            enzmldoc.set_creator( Creator("UNKNOWN", "UNKNOWN", "UNKNOWN") )
        
        try:
            model_hist = model.getModelHistory()
            enzmldoc.set_created(model_hist.getCreatedDate().getDateAsString())
            enzmldoc.set_modified(model_hist.getModifiedDate().getDateAsString())
        except AttributeError:
            enzmldoc.set_created("2020")
            enzmldoc.set_modified("2020")
               
        # Fetch units
        unitDict = self.__getUnits(model)
        enzmldoc.setUnitDict(unitDict)
        
        # Fetch Vessel
        vessel = self.__getVessel(model)
        enzmldoc.setVessel(vessel)
        
        # Fetch Species
        proteinDict, reactantDict = self.__getSpecies(model)
        enzmldoc.setReactantDict(reactantDict)
        enzmldoc.setProteinDict(proteinDict)
        
        # fetch reaction
        reactionDict = self.__getReactions(model)
        enzmldoc.setReactionDict(reactionDict)
        
        del self.__path
        
        return enzmldoc
        
    def __getCreators(self, model):
        
        model_hist = model.getModelHistory()
        creator_list = model_hist.getListCreators()
        creators = list()
        
        for creator in creator_list:

            creators.append(
                
                Creator(creator.getFamilyName(), creator.getGivenName(), creator.getEmail())
                
                )
            
        return creators
        
    def __getUnits(self, model):
        
        unitDict = dict()
        unitdef_list = model.getListOfUnitDefinitions()
        
        for unit in unitdef_list:
            
            name = unit.getName()
            id_ = unit.getId()
            metaid = unit.getMetaId()
            ontology = unit.getCVTerms()[0].getResourceURI(0)
            
            unitdef = UnitDef( name, id_, metaid, ontology  )
            
            for baseunit in unit.getListOfUnits():
                
                unitdef.addBaseUnit(
                    
                    baseunit.toXMLNode().getAttrValue('kind'),
                    baseunit.getExponentAsDouble(),
                    baseunit.getScale(),
                    baseunit.getMultiplier()
                    
                    )
                
            unitDict[id_] = unitdef
            
        return unitDict   

    def __getVessel(self, model):
        
        compartment = model.getListOfCompartments()[0]
        
        vessel = Vessel(
                            compartment.getName(), 
                            compartment.getId(), 
                            compartment.getMetaId(), 
                            compartment.getConstant(), 
                            compartment.getSize(), 
                            compartment.getUnits()
                        )
        
        return vessel

    def __getSpecies(self, model):
        
        proteinDict = dict()
        reactantDict = dict()
        species_list = model.getListOfSpecies()
        
        for species in species_list:   
            
            # Fetch protein sequence via annotation
            try:
            
                root = ET.fromstring(species.getAnnotationString())
                sequence = False
                
                # Iterate throufh annotation and fetch seqeunce
                for child1 in root:
                    if 'protein' in child1.tag:
                        
                        for child2 in child1:
                        
                            if 'sequence' in child2.tag:
                            
                                sequence = child2.text
                
                if sequence != False:
                    
                    # make sure that a sequence has been fetched
                    # Future might include normal reactant annotations
                    # thus making sure its a protein will be important
                    
                              
                    protein = Protein(
                                    species.getName(), 
                                    species.getId(), 
                                    species.getMetaId(), 
                                    sequence, 
                                    str(species.getSBOTerm()), 
                                    species.getCompartment(), 
                                    species.getInitialConcentration(), 
                                    species.getSubstanceUnits(), 
                                    species.getBoundaryCondition(), 
                                    species.getConstant()
                                    )
                    
                    proteinDict[species.getId()] = protein
                
            except ET.ParseError:
                
                # Reactants are parsed here if the species is not
                # matching protein conditions (sequence etc)
                
                reactant = Reactant(
                                    species.getName(), 
                                    species.getId(), 
                                    species.getMetaId(), 
                                    str(species.getSBOTerm()), 
                                    species.getCompartment(), 
                                    species.getInitialConcentration(), 
                                    species.getSubstanceUnits(), 
                                    species.getBoundaryCondition(), 
                                    species.getConstant()
                                    )
                    
                reactantDict[ species.getId() ] = reactant
         
        return proteinDict, reactantDict       

    def __getReactions(self, model):
        
        reaction_list = model.getListOfReactions()
        global_replicates = self.__getReplicates(reaction_list)
        reaction_replicates = dict()
        
        reactionDict = dict()
        
        # parse annotations and filter replicates
        for reac in reaction_list:
            
            root = ET.fromstring(reac.getAnnotationString())
            
            for child in list(root)[0]:
                
                if "conditions" in child.tag:
                    
                    for cond in child:
                        # iterate through conditions 
                        if 'ph' in cond.tag: ph=float(cond.attrib["value"]);
                        if 'temperature' in cond.tag: temperature=float(cond.attrib["value"]);
                        if 'temperature' in cond.tag: tempunit=cond.attrib["unit"];
                        
                elif 'replica' in child.tag:

                    for repl in child:
                        # iterate through replicates
                        repl_id = repl.attrib["replica"]
                        replica = global_replicates[repl_id]
                        
                        try:
                            reaction_replicates[replica.getReactant()].append( replica )
                        except KeyError:
                            reaction_replicates[replica.getReactant()] = [replica]
            
            # parse list of educts/products/modifiers
            educts = [ 
                
                         ( species_ref.getSpecies(),
                         species_ref.getStoichiometry(),
                         species_ref.getConstant(),
                         reaction_replicates[ species_ref.getSpecies() ]
                         ) if species_ref.getSpecies() in reaction_replicates.keys()
                         
                         else ( species_ref.getSpecies(),
                         species_ref.getStoichiometry(),
                         species_ref.getConstant(),
                         list()
                         )
                      
                        for species_ref in reac.getListOfReactants() 
                        
                        ]
            
            products = [ 
                
                         ( species_ref.getSpecies(),
                         species_ref.getStoichiometry(),
                         species_ref.getConstant(),
                         reaction_replicates[ species_ref.getSpecies() ]
                         ) if species_ref.getSpecies() in reaction_replicates.keys()
                         
                         else ( species_ref.getSpecies(),
                         species_ref.getStoichiometry(),
                         species_ref.getConstant(),
                         list()
                         )
                      
                        for species_ref in reac.getListOfProducts()
                        
                        ]
            
            modifiers = [ 
                
                         ( species_ref.getSpecies(),
                         reaction_replicates[ species_ref.getSpecies() ]
                         ) if species_ref.getSpecies() in reaction_replicates.keys()
                         
                         else ( species_ref.getSpecies(),
                         list()
                         )
                      
                        for species_ref in reac.getListOfModifiers()
                        
                        ]
            
            reactionDict[reac.getId()] = EnzymeReaction(
                
                temperature, 
                tempunit, 
                ph, 
                reac.getName(), 
                reac.getReversible(), 
                reac.getId(), 
                reac.getMetaId(), 
                educts, 
                products, 
                modifiers
                
                )
            
            try:
                
                kinlaw = reac.getKineticLaw()
                equation = kinlaw.getFormula()
                
                parameters = { loc_param.getId(): loc_param.getValue() 
                               for loc_param in kinlaw.getListOfLocalParameters() }
                
                reactionDict[reac.getId()].setModel(
                    
                    KineticModel(equation, parameters)
                    
                    )
                
            except AttributeError:
                pass
            
        return reactionDict   
            
            
    def __getReplicates(self, reaction_list):
        
        root = ET.fromstring(reaction_list.getAnnotationString())[0]
        
        listOfFiles = [ file.attrib['file'] 
                        for child in root 
                            for file in child 
                                if 'listOfFiles' in child.tag  ]
        
        # load csv file to extract replicate data
        
        if self.omex:
            
            csv_entry = self.archive.getEntry(1)
            content = self.archive.extractEntryToString(csv_entry.getLocation())
            csv_data = StringIO(content)
        
            listOfCSV = [
                    
                    pd.read_csv( csv_data, header=None )
                
                ]
         
        else:
                
            listOfCSV = [
                    
                    pd.read_csv( self.__path + path_csv[1::], header=None )
                    for path_csv in listOfFiles
                
                ]
        
        """TODO PROCESS ALL MEAS DATA"""
        
        data = listOfCSV[0]
        
        listOfFormats = [ file 
                        for child in root 
                            for file in child 
                                if 'listOfFormats' in child.tag  ]
        
        # Name columns accordingly
        columns = [ "time"  if child.attrib["type"] == "time"
                    else "%s/%s" % ( child.attrib["replica"], child.attrib["species"] )
                        
                        for format_ in listOfFormats
                        for child in format_
                    ]
        
        # get unit of time
        time_unit = [ child.attrib["unit"]
                        for format_ in listOfFormats
                        for child in format_
                        if child.attrib["type"] == "time"
                    ][0]
        
        data.columns = columns
        data.set_index("time", inplace=True)
        
        # derive data from annotations
        replicates = dict()
        for format_ in listOfFormats:
            for child in format_:
                
                if child.attrib["type"] != "time":
                    
                    repl = Replicate(   child.attrib["replica"], 
                                        child.attrib["species"], 
                                        child.attrib["type"], 
                                        child.attrib["unit"], 
                                        time_unit
                                        )
                    
                    repl.setData( data[ "%s/%s" % ( child.attrib["replica"], child.attrib["species"] ) ] )
                    
                    replicates[ repl.getReplica() ] = repl
        
        return replicates