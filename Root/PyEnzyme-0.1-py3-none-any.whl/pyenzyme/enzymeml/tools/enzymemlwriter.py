'''
Created on 11.08.2020

@author: JR
'''
from libsbml import SBMLDocument, CVTerm, XMLNode, XMLTriple, XMLAttributes,\
    XMLNamespaces, SBMLWriter
import libsbml
from libsbml._libsbml import BIOLOGICAL_QUALIFIER, BQB_IS
from libcombine import CombineArchive, OmexDescription, KnownFormats, VCard
import pandas as pd
import numpy as np
import os

class EnzymeMLWriter(object):
    '''
    classdocs
    '''

    def toFile(self, enzmldoc, path):
        
        self.path = path + '/' + enzmldoc.getName()
        
        try:
            os.makedirs( self.path + '/data' )
        except FileExistsError:
            pass
        
        doc = SBMLDocument()
        doc.setLevelAndVersion(enzmldoc.getLevel(), enzmldoc.getVersion())
        
        model = doc.createModel()
        model.setName(enzmldoc.getName())
        model.setId(enzmldoc.getName())
        
        # Add units
        self.addUnits(model, enzmldoc)
        
        # Add Vessel
        self.addVessel(model, enzmldoc)
        
        # Add protein
        self.addProteins(model, enzmldoc)
        
        # Add reactants
        self.addReactants(model, enzmldoc)
        
        # Add reactions
        self.addReactions(model, enzmldoc)
        
        # Write to EnzymeML
        writer = SBMLWriter()
        writer.writeSBMLToFile(doc, self.path + '/experiment.xml')
        
        # Write to OMEX
        self.createArchive(enzmldoc, doc)
        
        os.remove(self.path + '/experiment.xml')
        os.remove(self.path + '/data/data.csv')
        os.rmdir(self.path + '/data')
        
    def createArchive(self, enzmldoc, doc):
    
        archive = CombineArchive()
        archive.addFile(
            self.path + '/experiment.xml',  # filename
            "./experiment.xml",  # target file name
            KnownFormats.lookupFormat("sbml"),  # look up identifier for SBML models
            True  # mark file as master
        )
        
        archive.addFile(
            self.path + '/data/data.csv',  # filename
            "./data/data.csv",  # target file name
            KnownFormats.lookupFormat("csv"),  # look up identifier for SBML models
            False  # mark file as master
        )
    
        # add metadata to the archive itself
        description = OmexDescription()
        description.setAbout(".")
        description.setDescription(enzmldoc.getName())
        description.setCreated(OmexDescription.getCurrentDateAndTime())
        
        for creat in enzmldoc.get_creator():
            
            creator = VCard()
            creator.setFamilyName(creat.getFname())
            creator.setGivenName(creat.getGname())
            creator.setEmail(creat.getMail())
    
            description.addCreator(creator)
    
        archive.addMetadata(".", description)
    
        # add metadata to the experiment file
        location = "./experiment.xml"
        description = OmexDescription()
        description.setAbout(location)
        description.setDescription("EnzymeML model")
        description.setCreated(OmexDescription.getCurrentDateAndTime())
        archive.addMetadata(location, description)
        
        # add metadata to the csv file
        location = "./data/data.csv"
        description = OmexDescription()
        description.setAbout(location)
        description.setDescription("EnzymeML Time Course Data")
        description.setCreated(OmexDescription.getCurrentDateAndTime())
        archive.addMetadata(location, description)
    
        # write the archive
        out_file = "%s.omex" % enzmldoc.getName().replace(' ', '_')
        archive.writeToFile(self.path + '/' + out_file)
    
        print('\nArchive created:', out_file)
        
    def addUnits(self, model, enzmldoc):
        
        for key, unitdef in enzmldoc.getUnitDict().items():
            
            unit = model.createUnitDefinition()
            unit.setId(key)
            unit.setMetaId(unitdef.getMetaid())
            unit.setName(unitdef.getName())
            
            cvterm = CVTerm()
            cvterm.addResource(unitdef.getOntology())
            cvterm.setQualifierType(BIOLOGICAL_QUALIFIER)
            cvterm.setBiologicalQualifierType(BQB_IS)
            unit.addCVTerm(cvterm)
            
            for baseunit in unitdef.getUnits():
                
                u = unit.createUnit()
                u.setKind( libsbml.UnitKind_forName(baseunit[0]) )
                u.setExponent( baseunit[1] )
                u.setScale( baseunit[2] )
                u.setMultiplier( baseunit[3] )
                
    def addVessel(self, model, enzmldoc):
        
        vessel = enzmldoc.getVessel()
        
        compartment = model.createCompartment()
        compartment.setId(vessel.getId())
        compartment.setName(vessel.getName())
        compartment.setUnits(vessel.getUnit())
        compartment.setSize(vessel.getSize())
        compartment.setConstant(vessel.getConstant())
        compartment.setSpatialDimensions(3)
        
    def addProteins(self, model, enzmldoc):
        
        for key, protein in enzmldoc.getProteinDict().items():
            
            species = model.createSpecies()
            species.setId(key)
            species.setName(protein.getName())
            species.setMetaId(protein.getMetaid())
            species.setSBOTerm(protein.getSboterm())
            species.setCompartment(protein.getCompartment())
            species.setBoundaryCondition(protein.getBoundary());
            species.setInitialConcentration(protein.getInitConc());
            species.setSubstanceUnits(protein.getSubstanceUnits());
            
            # add annotation
            annot_root = XMLNode( XMLTriple('enzymeml:protein'), XMLAttributes(), XMLNamespaces() )
            annot_root.addNamespace("http://sbml.org/enzymeml/version1", "enzymeml")
            
            annot_sequence = XMLNode( XMLTriple('enzymeml:sequence'), XMLAttributes(), XMLNamespaces() )
            sequence = XMLNode(protein.getSequence())
            
            annot_sequence.addChild(sequence)
            annot_root.addChild(annot_sequence)
            
            species.appendAnnotation(annot_root)
            
    def addReactants(self, model, enzmldoc):
        
        for key, reactant in enzmldoc.getReactantDict().items():
            
            species = model.createSpecies()
            species.setId(key)
            species.setName(reactant.getName())
            species.setMetaId(reactant.getMetaid())
            species.setSBOTerm(reactant.getSboterm())
            species.setCompartment(reactant.getCompartment())
            species.setBoundaryCondition(reactant.getBoundary());
            species.setInitialConcentration(reactant.getInitConc());
            species.setSubstanceUnits(reactant.getSubstanceunits());
            
            try:
                inchi_annot = XMLNode( XMLTriple('enzymeml:inchi'), XMLAttributes(), XMLNamespaces() )
                inchi_annot.addNamespace("http://sbml.org/enzymeml/version1", "enzymeml")
                inchi_annot.addAttr('inchi', reactant.getInchi())
                species.appendAnnotation(inchi_annot)
            except AttributeError:
                pass
            
            try:
                smiles_annot = XMLNode( XMLTriple('enzymeml:smiles'), XMLAttributes(), XMLNamespaces() )
                smiles_annot.addNamespace("http://sbml.org/enzymeml/version1", "enzymeml")
                smiles_annot.addAttr('smiles', reactant.getSmiles())
                species.appendAnnotation(smiles_annot)
            except AttributeError:
                pass
            
            
    def addReactions(self, model, enzmldoc):
        
        # initialize format annotation
        data_root = XMLNode( XMLTriple('enzymeml:data'), XMLAttributes(), XMLNamespaces() )
        data_root.addNamespace("http://sbml.org/enzymeml/version1", "enzymeml")
        
        list_formats = XMLNode( XMLTriple('enzymeml:listOfFormats'), XMLAttributes(), XMLNamespaces() )
        format_ = XMLNode( XMLTriple('enzymeml:format'), XMLAttributes(), XMLNamespaces() )
        format_.addAttr( 'id', 'format0' )
        
        # initialize csv data collection
        data = []
        
        for key, reac in enzmldoc.getReactionDict().items():
            
            reaction = model.createReaction()
            reaction.setName(reac.getName())
            reaction.setId(key)
            reaction.setMetaId(reac.getMetaid())
            reaction.setReversible(reac.getReversible())
            
            # initialize conditions annotations
            annot_root = XMLNode( XMLTriple('enzymeml:reaction'), XMLAttributes(), XMLNamespaces() )
            annot_root.addNamespace("http://sbml.org/enzymeml/version1", "enzymeml")
            
            conditions_root = XMLNode( XMLTriple('enzymeml:conditions'), XMLAttributes(), XMLNamespaces() )
            
            temp_node = XMLNode( XMLTriple('enzymeml:temperature'), XMLAttributes(), XMLNamespaces() )
            temp_node.addAttr('value', str(reac.getTemperature()) )
            temp_node.addAttr('unit', reac.getTempunit())
            
            ph_node = XMLNode( XMLTriple('enzymeml:ph'), XMLAttributes(), XMLNamespaces() )
            ph_node.addAttr('value', str(reac.getPh()) )
            
            conditions_root.addChild(temp_node)
            conditions_root.addChild(ph_node)
            
            annot_root.addChild(conditions_root)
            
            # initialize replica/format annotations
            replica_root = XMLNode( XMLTriple('enzymeml:replicas'), XMLAttributes(), XMLNamespaces() )
            
            # initialize time
            index = 0
            replicate = [ rep for educt in reac.getEducts() for rep in educt[3] ][0]
            time = replicate.getData().index.tolist()
            time_unit = replicate.getTimeUnit()
            
            time_node = XMLNode( XMLTriple('enzymeml:column'), XMLAttributes(), XMLNamespaces() )
            time_node.addAttr('type', 'time')
            time_node.addAttr('unit', time_unit)
            time_node.addAttr('index', str(index) )
            
            format_.addChild(time_node)
            data.append( time )
            index += 1
            
            # iterate over lists
            # educts
            for educt in reac.getEducts():
                
                species = educt[0]
                stoich = educt[1]
                const = educt[2]
                
                specref = reaction.createReactant()
                specref.setSpecies(species)
                specref.setStoichiometry(stoich)
                specref.setConstant(const)
                
                for repl in educt[3]:
                    
                    repl_node = XMLNode( XMLTriple('enzymeml:replica'), XMLAttributes(), XMLNamespaces() )
                    repl_node.addAttr('measurement', 'M0')
                    repl_node.addAttr('replica', repl.getReplica())
                    
                    form_node = XMLNode( XMLTriple('enzymeml:column'), XMLAttributes(), XMLNamespaces() )
                    form_node.addAttr( 'replica', repl.getReplica() )
                    form_node.addAttr( 'species', repl.getReactant() )
                    form_node.addAttr( 'type', repl.getType() )
                    form_node.addAttr( 'unit', repl.getDataUnit() )
                    form_node.addAttr( 'index', str(index) )
                        
                    replica_root.addChild(repl_node)
                    format_.addChild(form_node)
                    
                    data.append( repl.getData().values.tolist() )
                    
                    index += 1
                    
            # products
            for product in reac.getProducts():
                
                species = product[0]
                stoich = product[1]
                const = product[2]
                
                specref = reaction.createProduct()
                specref.setSpecies(species)
                specref.setStoichiometry(stoich)
                specref.setConstant(const)
                
                for repl in product[3]:
                    
                    repl_node = XMLNode( XMLTriple('enzymeml:replica'), XMLAttributes(), XMLNamespaces() )
                    repl_node.addAttr('measurement', 'M0')
                    repl_node.addAttr('replica', repl.getReplica())
                    
                    form_node = XMLNode( XMLTriple('enzymeml:column'), XMLAttributes(), XMLNamespaces() )
                    form_node.addAttr( 'replica', repl.getReplica() )
                    form_node.addAttr( 'species', repl.getReactant() )
                    form_node.addAttr( 'type', repl.getType() )
                    form_node.addAttr( 'unit', repl.getDataUnit() )
                    form_node.addAttr( 'index', str(index) )
                        
                    replica_root.addChild(repl_node)
                    format_.addChild(form_node)
                    
                    data.append( repl.getData().values.tolist() )
                    
                    index += 1
                    
            # modifiers
            for modifier in reac.getModifiers():
                
                species = modifier[0]
                
                specref = reaction.createModifier()
                specref.setSpecies(species)
                
                for repl in modifier[1]:
                    
                    repl_node = XMLNode( XMLTriple('enzymeml:replica'), XMLAttributes(), XMLNamespaces() )
                    repl_node.addAttr('measurement', 'M0')
                    repl_node.addAttr('replica', repl.getReplica())
                    
                    form_node = XMLNode( XMLTriple('enzymeml:column'), XMLAttributes(), XMLNamespaces() )
                    form_node.addAttr( 'replica', repl.getReplica() )
                    form_node.addAttr( 'species', repl.getReactant() )
                    form_node.addAttr( 'type', repl.getType() )
                    form_node.addAttr( 'unit', repl.getDataUnit() )
                    form_node.addAttr( 'index', str(index) )
                        
                    replica_root.addChild(repl_node)
                    format_.addChild(form_node)
                    
                    data.append( repl.getData().values.tolist() )
                    
                    index += 1
            
            try:
                # add kinetic law if existent
                reac.getModel().addToReaction(reaction)
            except AttributeError:
                pass
            
            annot_root.addChild( replica_root )
            reaction.appendAnnotation(annot_root)
            
        # finalize all reactions
        list_formats.addChild(format_)
        
        list_measurements = XMLNode( XMLTriple('enzymeml:listOfMeasurements'), XMLAttributes(), XMLNamespaces() )
        
        meas = XMLNode( XMLTriple('enzymeml:measurement'), XMLAttributes(), XMLNamespaces() )
        meas.addAttr('file', 'file0')
        meas.addAttr('id', 'M0')
        meas.addAttr('name', 'AnyName')
        
        list_measurements.addChild(meas)
        
        list_files = XMLNode( XMLTriple('enzymeml:listOfFiles'), XMLAttributes(), XMLNamespaces() )
        
        file = XMLNode( XMLTriple( 'enzymeml:file' ), XMLAttributes(), XMLNamespaces() )
        file.addAttr('file', './data/Data.csv')
        file.addAttr('format', 'format0')
        file.addAttr('id', 'file0')
        
        list_files.addChild(file)
        
        # write file to csv
        df = pd.DataFrame( np.array(data).T )
        df.to_csv( self.path + '/data/data.csv', index=False, header=False)
        
        data_root.addChild(list_formats)
        data_root.addChild(list_files)
        data_root.addChild(list_measurements)
    
        model.getListOfReactions().appendAnnotation(data_root)