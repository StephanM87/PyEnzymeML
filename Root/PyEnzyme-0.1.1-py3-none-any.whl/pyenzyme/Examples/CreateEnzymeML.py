'''
Created on 12.08.2020

@author: JR
'''

from pyenzyme.enzymeml.core import EnzymeReaction, EnzymeMLDocument, Reactant, Vessel
from pyenzyme.enzymeml.tools import EnzymeMLWriter
from pyenzyme.enzymeml.core.replicate import Replicate
import pandas as pd

enzmldoc = EnzymeMLDocument('TEST', 3, 2)

vessel = Vessel('name', 'id_', 'metaid', True, 10.0, 'unit')
enzmldoc.setVessel(vessel)

reactant = Reactant("name", "s0", "metaid", "sboterm", "compartment_id", 5.0, "substance_units", True, True)
enzmldoc.addReactant(reactant)

reac = EnzymeReaction(10.0, 'C', 7.0, "reaciton", True, "r0", 'META_R0')
reac.addEduct('s0', 1.0, True, enzmldoc)

repl = Replicate("replica", "s0", "conc", "nM", "seconds")
data = pd.Series([1,2,3,4,5,6,7])
data.Index = [1,2,3,4,5,6,7]
repl.setData(data)

reac.addReplicate(repl)

enzmldoc.addReaction(reac)

writer = EnzymeMLWriter()
writer.toFile(enzmldoc, '../Resources/Examples/CreateEnzymeML')