'''
Created on 10.06.2020

@author: JR
'''
from pyenzyme.enzymeml.core.functionalities import TypeChecker


class UnitDef(object):
    
    def __init__(self, name, id_, metaid, ontology):
        
        '''
        Class describing substance units.
        
        Args:
            units: List of BaseUnits
            name: Systematical name of unit
            id_: Internal Identifier
            metaid: Internal Meta Identifier
            ontology: Link to ontology 
        '''
        
        self.setUnits(list())
        
        self.setName(name)
        self.setId(id_)
        self.setMetaid(metaid)
        self.setOntology(ontology)
        
    def addBaseUnit(self, kind, exponent, scale, multiplier):
        
        '''
        Adds defining base unit such as litre or grams to a unit definition
        
        Args:
            kind: SBML internal definition for Base Units
            exponent: Float value of exponent in Unit
            scale: Integer value to define (m, mu etc)
            multiplier: FLoat value to multiply unit
        '''
        
        self.__units.append( 
            
            ( 
                kind, 
                TypeChecker(exponent, float) ,
                TypeChecker(scale, int),
                TypeChecker(multiplier, float)
              ) 
            )
        

    def getUnits(self):
        return self.__units


    def getName(self):
        return self.__name


    def getId(self):
        return self.__id


    def getMetaid(self):
        return self.__metaid


    def getOntology(self):
        return self.__ontology


    def setUnits(self, units):
        self.__units = TypeChecker( units, list )


    def setName(self, name):
        self.__name = TypeChecker(name, str)


    def setId(self, id_):
        self.__id = TypeChecker(id_, str)


    def setMetaid(self, metaid):
        self.__metaid = TypeChecker(metaid, str)


    def setOntology(self, ontology):
        self.__ontology = TypeChecker(ontology, str)


    def delUnits(self):
        del self.__units


    def delName(self):
        del self.__name


    def delId(self):
        del self.__id


    def delMetaid(self):
        del self.__metaid


    def delOntology(self):
        del self.__ontology

    _units = property(getUnits, setUnits, delUnits, "_units's docstring")
    _name = property(getName, setName, delName, "_name's docstring")
    _id = property(getId, setId, delId, "_id's docstring")
    _metaid = property(getMetaid, setMetaid, delMetaid, "_metaid's docstring")
    _ontology = property(getOntology, setOntology, delOntology, "_ontology's docstring")

    