'''
Created on 09.06.2020

@author: JR
'''
from pyenzyme.enzymeml.core.functionalities import TypeChecker
from pyenzyme.enzymeml.models.kineticmodel import KineticModel
from pyenzyme.enzymeml.core.replicate import Replicate


class EnzymeReaction(object):

    def __init__(self, temperature, tempunit, ph, name, reversible, id_, metaid, educts=list(), products=list(), modifiers=list()):
        '''
        Class to describe an enzyme reaction, its molecules/proteins, data and models
        
        Args:
            temperature: Numerical value for temperature
            tempunit: Unit for temperature
            ph: pH value [0-14]
            name: Enzyme Reaction Name
            reversible: Is Reversible bool
            id_: Internal identifier
            metaid: Internal meta identifier
            educts: List of tuples ( Reactant ID, Stoichiometry, Constant?, List Of Replicates )
            products: List of tuples ( Reactant ID, Stoichiometry, Constant?, List Of Replicates )
            modifiers: List of tuples ( Reactant ID, Stoichiometry, Constant?, List Of Replicates )
        '''
        
        self.setTemperature(temperature)
        self.setTempunit(tempunit)
        self.setPh(ph)
        self.setName(name)
        self.setReversible(reversible)
        self.setId(id_)
        self.setMetaid(metaid)
        self.setEducts(educts)
        self.setProducts(products)
        self.setModifiers(modifiers)
        
    def addReplicate(self, replicate):
        
        try:
            replicate.getData()
        except AttributeError:
            raise AttributeError( "Replicate has no series data. Add data via .setData( pandas.Series )" )
        
        for i in range(len(self.__educts)):
            if self.__educts[i][0] is replicate.getReactant():
                self.__educts[i][-1].append(replicate)
                return 1
            
        for i in range(len(self.__products)):
            if self.__educts[i][0] is replicate.getReactant():
                self.__educts[i][-1].append(replicate)
                return 1
            
        for i in range(len(self.__modifiers)):
            if self.__educts[i][0] is replicate.getReactant():
                self.__educts[i][-1].append(replicate)
                return 1
            
        raise AttributeError( "Replicate's reactant %s not defined in reaction" % (replicate.getReactant()) )
        
    def addEduct(self, id_, stoichiometry, constant, enzmldoc, replicates=[]):
        
        id_ = TypeChecker(id_, str)
        
        if id_ not in enzmldoc.getReactantDict().keys():
            raise KeyError( "Reactant with id %s is not defined yet" % id_ )
        
        stoichiometry = TypeChecker(stoichiometry, float)
        constant = TypeChecker(constant, bool)
        
        if type(replicates) == list and len(replicates) > 0:
            replicates = replicates
        elif type(replicates) == list and len(replicates) == 0:
            replicates = []
        elif type(replicates) == Replicate:
            replicates = [replicates]
        
        
        self.__educts.append(
            
            (
                id_,
                stoichiometry,
                constant,
                replicates
                )
            
            )
        
    def addProduct(self, id_, stoichiometry, constant, enzmldoc, replicates=[]):
        
        id_ = TypeChecker(id_, str)
        
        if id_ not in enzmldoc.getReactantDict().keys():
            raise KeyError( "Reactant with id %s is not defined yet" % id_ )
        
        stoichiometry = TypeChecker(stoichiometry, float)
        constant = TypeChecker(constant, bool)
        
        if type(replicates) == list and len(replicates) > 0:
            replicates = replicates
        elif type(replicates) == list and len(replicates) == 0:
            replicates = []
        elif type(replicates) == Replicate:
            replicates = [replicates]
        
        self.__products.append(
            
            (
                id_,
                stoichiometry,
                constant,
                replicates
                )
            
            )
        
    def addModifier(self, id_, stoichiometry, constant, enzmldoc, replicates=[]):
        
        id_ = TypeChecker(id_, str)
        
        
        if id_ not in enzmldoc.getReactantDict().keys() or id_ not in enzmldoc.getProteinDict().keys():
            raise KeyError( "Reactant/Protein with id %s is not defined yet" % id_ )
        
        stoichiometry = TypeChecker(id_, float)
        constant = TypeChecker(id_, bool)
        
        if type(replicates) == list and len(replicates) > 0:
            replicates = replicates
        elif type(replicates) == list and len(replicates) == 0:
            replicates = []
        elif type(replicates) == Replicate:
            replicates = [replicates]
        
        self.__modifiers.append(
            
            (
                id_,
                stoichiometry,
                constant,
                replicates
                )
            
            )
    
    def getTemperature(self):
        return self.__temperature


    def getTempunit(self):
        return self.__tempunit


    def getPh(self):
        return self.__ph


    def getName(self):
        return self.__name


    def getReversible(self):
        return self.__reversible


    def getId(self):
        return self.__id


    def getMetaid(self):
        return self.__metaid


    def getModel(self):
        return self.__model


    def getEducts(self):
        return self.__educts


    def getProducts(self):
        return self.__products


    def getModifiers(self):
        return self.__modifiers


    def setTemperature(self, temperature):
        self.__temperature = TypeChecker(temperature, float)


    def setTempunit(self, tempunit):
        self.__tempunit = TypeChecker(tempunit, str)


    def setPh(self, ph):
        
        if 0 <= TypeChecker(ph, float) <= 14:
            self.__ph = ph
            
        else:
            raise ValueError( "pH out of bounds [0-14]" )


    def setName(self, name):
        self.__name = TypeChecker(name, str)


    def setReversible(self, reversible):
        self.__reversible = TypeChecker(reversible, bool)


    def setId(self, id_):
        self.__id = TypeChecker(id_, str)


    def setMetaid(self, metaID):
        self.__metaid = TypeChecker(metaID, str)


    def setModel(self, model):
        self.__model = TypeChecker(model, KineticModel)


    def setEducts(self, educts):
        self.__educts = TypeChecker(educts, list)


    def setProducts(self, products):
        self.__products = TypeChecker(products, list)


    def setModifiers(self, modifiers):
        self.__modifiers = TypeChecker(modifiers, list)


    def delTemperature(self):
        del self.__temperature


    def delTempunit(self):
        del self.__tempunit


    def delPh(self):
        del self.__ph


    def delName(self):
        del self.__name


    def delReversible(self):
        del self.__reversible


    def delId(self):
        del self.__id


    def delMetaid(self):
        del self.__metaid


    def delModel(self):
        del self.__model


    def delEducts(self):
        del self.__educts


    def delProducts(self):
        del self.__products


    def delModifiers(self):
        del self.__modifiers

    _temperature = property(getTemperature, setTemperature, delTemperature, "_temperature's docstring")
    _tempunit = property(getTempunit, setTempunit, delTempunit, "_tempunit's docstring")
    _ph = property(getPh, setPh, delPh, "_ph's docstring")
    _name = property(getName, setName, delName, "_name's docstring")
    _reversible = property(getReversible, setReversible, delReversible, "_reversible's docstring")
    _id = property(getId, setId, delId, "_id's docstring")
    _metaid = property(getMetaid, setMetaid, delMetaid, "_metaid's docstring")
    _model = property(getModel, setModel, delModel, "_model's docstring")
    _educts = property(getEducts, setEducts, delEducts, "_educts's docstring")
    _products = property(getProducts, setProducts, delProducts, "_products's docstring")
    _modifiers = property(getModifiers, setModifiers, delModifiers, "_modifiers's docstring")

    
        