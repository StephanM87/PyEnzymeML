'''
Created on 09.06.2020

@author: JR
'''

from pyenzyme.enzymeml.core.functionalities import TypeChecker


class Protein(object):

    def __init__(self, name, id_, metaid, sequence, sboterm, compartment_id, init_conc, substance_units, boundary, constant):
        '''
        Args:
            name: Systematic protein name
            id_: Internal identifier
            metaid: Internal Meta ID
            sequence: Protein amino acid sequence
            sboterm: SBOTerm
            compartment_id: Vessel Identifier
            init_conc: Initial protein concentration
            substance_units: Unit definition
            boundary: boolean
            constant: boolean
        '''
        
        self.setName(name)
        self.setId(id_)
        self.setMetaid(metaid)
        self.setSequence(sequence)
        self.setSboterm(sboterm)
        self.setCompartment(compartment_id)
        self.setInitConc(init_conc)
        self.setSubstanceUnits(substance_units)
        self.setBoundary(boundary)
        self.setConstant(constant)

    def getInitConc(self):
        return self.__init_conc


    def setInitConc(self, init_conc):
        self.__init_conc = TypeChecker(init_conc, float)


    def delInitConc(self):
        del self.__init_conc


    def getName(self):
        return self.__name


    def getId(self):
        return self.__id


    def getMetaid(self):
        return self.__metaid


    def getSequence(self):
        return self.__sequence


    def getSboterm(self):
        return self.__sboterm


    def getCompartment(self):
        return self.__compartment


    def getSubstanceUnits(self):
        return self.__substance_units


    def getBoundary(self):
        return self.__boundary


    def getConstant(self):
        return self.__constant


    def setName(self, name):
        self.__name = TypeChecker(name, str)


    def setId(self, id_):
        self.__id = TypeChecker(id_, str)


    def setMetaid(self, metaid):
        self.__metaid = TypeChecker(metaid, str)


    def setSequence(self, sequence):
        self.__sequence = TypeChecker(sequence, str)


    def setSboterm(self, sboterm):
        self.__sboterm = TypeChecker(sboterm, str)


    def setCompartment(self, compartment_id):
        self.__compartment = TypeChecker(compartment_id, str)


    def setSubstanceUnits(self, unit_id):
        self.__substance_units = TypeChecker(unit_id, str)


    def setBoundary(self, boundary):
        self.__boundary = TypeChecker(boundary, bool)


    def setConstant(self, constant):
        self.__constant = TypeChecker(constant, bool)


    def delName(self):
        del self.__name


    def delId(self):
        del self.__id


    def delMetaid(self):
        del self.__metaid


    def delSequence(self):
        del self.__sequence


    def delSboterm(self):
        del self.__sboterm


    def delCompartment(self):
        del self.__compartment


    def delSubstanceUnits(self):
        del self.__substance_units


    def delBoundary(self):
        del self.__boundary


    def delConstant(self):
        del self.__constant

    _name = property(getName, setName, delName, "_name's docstring")
    _id = property(getId, setId, delId, "_id's docstring")
    _metaid = property(getMetaid, setMetaid, delMetaid, "_metaid's docstring")
    _sequence = property(getSequence, setSequence, delSequence, "_sequence's docstring")
    _sboterm = property(getSboterm, setSboterm, delSboterm, "_sboterm's docstring")
    _compartment = property(getCompartment, setCompartment, delCompartment, "_compartment's docstring")
    _substance_units = property(getSubstanceUnits, setSubstanceUnits, delSubstanceUnits, "_substance_units's docstring")
    _boundary = property(getBoundary, setBoundary, delBoundary, "_boundary's docstring")
    _constant = property(getConstant, setConstant, delConstant, "_constant's docstring")
    _init_conc = property(getInitConc, setInitConc, delInitConc, "_init_conc's docstring")
    
    
        
        